jQuery(document).ready(function($){
    $('.videojs-color-field').wpColorPicker();
});
